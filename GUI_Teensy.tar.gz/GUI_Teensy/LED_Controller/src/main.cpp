/*!
 * \author Eric Sauber & Kevin Tiller
 * \version 1.0
 * \date 11-16-2016
 * \mainpage The Teensy LED Controller
 * \section intro_sec Introduction
 * To control the color of light from the LED through slider and text entry input (values from 0 to 255).
 Colors being Red, Green, and Blue.
 Control the voltage by obtaining the ADC value from the potentiometer.
 * 
 * The code doesn't work, but our documentation is on point.

 * The problem: have the teensy accept the required input.

 * Proper use of checksum to send to the serial port. 
  * \subsection From Lab Report 9
 * Your next task is to finish the Teensy code under Teensy\_code/led\_and\_pot\_serial; your code is supposed to go under "while (isRunning)". You may notice some changes in this code (e.g., to overcome an analog-write bug in the Teensy 3.2 micro-controller board's Arduino interface we increased the PWM resolution from 8 bits to 16 bits; this way you can actually mostly turn off the LEDs). You can also see that if you send a properly formatted packet with the first payload byte equaling the ASCII 'L', then the next three bytes are going to represent the brightness values for the red, the green, and the blue part of the LED respectively.\\
You will need to add code that obtains an ADC value from the potentiometer and if this value has changed since the last time the value was obtained then you need to assemble a properly formatted packet and send it off the serial port. The properly formatted packet is framed the same way we did in previous labs (e.g., by calling sendPacket()); the payload for this packet is three bytes as follows. The first payload byte should be the ASCII value for capital 'P' (signaling the other side that the incoming packet contains a reading from a potentiometer). The ADC conversion on the potentiometer results in a 10-bit number (between 0 and 1023); you will need to separate this value into two bytes: the high-byte containing the upper (most significant) two bits and the low-byte containing the eight least significant bits. After the 'P' then you will first need to send the high-byte then the low byte (three bytes of payload all together).\\

You can test your code by running the TeensyControl executable from the Executable\_LED\_Controller directory. Make sure that the port description on top of this GUI is correct, open the port and try to control the LEDs and receive the potentiometer's value by turning it.\\
Show your success to the TA.\\\\

Your next task is to recreate the TeensyControl executable for which you can find a skeleton in LED\_Controller. Complete the GUI, and the missing parts in main.cpp, global.h and serialthread.cpp.\\

The serialthread.cpp file contains the implementation of the thread that handles reading from the serial port (this is where you will need to implement creating packages from received bytes, validating the packets, and checking if there is an incoming 'P'-command; hint: you can find implementations for most of these in the Teensy code...).

Once you are done, demonstrate your work to the TA starting with a clean build of your project. Turn in both this document as well as your source code (cleaned of object files and executables).


*/
#include "global.h"
#include "string.h"
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include <unistd.h>
#include <termios.h>

#define VOLTAGE_DISPLAY_UPDATE_MS 100

/*!
 * \brief Connects the widget pointers to the glade widgets
 * \param p_builder pointer to the builder structure
 * \details For this function to work, the widget class must have pointers for all widgets that we want to modify 
 * from the code.
 */
void ObtainGuiWidgets(GtkBuilder *p_builder)
{
  #define GuiappGET(xx) gui_app->xx=GTK_WIDGET(gtk_builder_get_object(p_builder,#xx))
  GuiappGET(window1);
  GuiappGET(entry_sd);
  GuiappGET(label_voltage);
  GuiappGET(entry_red);
  GuiappGET(entry_green);
  GuiappGET(entry_blue);
  GuiappGET(scale_red);
  GuiappGET(scale_green);
  GuiappGET(scale_blue);
  GuiappGET(button_closedevice);
  GuiappGET(button_opendevice);
    
}


/*!
 * \brief Displays the voltage
 * \param p_gptr gpointer recieve the proper data.
 * \details Displays the voltage based on the the voltage the LED is using the influence from the potentiometer.
 */
gboolean  Voltage_Display_Displayer(gpointer p_gptr)
{
  // do not change this function
  g_mutex_lock(mutex_to_protect_voltage_display);
  gtk_label_set_text(GTK_LABEL(gui_app->label_voltage),c_voltage_value);
  g_mutex_unlock(mutex_to_protect_voltage_display);
  return true;
}

/*!
 * \brief Checks if the "Open Device" button was clicked.
 * \param p_wdgt pointer to the widget structure
 * \param p_data gpointer to tell whether the button was clicked or not
 * \details Opens up the device, allowing access to the program for use.
 */
extern "C" void button_opendevice_clicked(GtkWidget *p_wdgt, gpointer p_data ) 
{
  //do not change  the next few lines
  //they contain the mambo-jumbo to open a serial port
  
  const char *t_device_value;
  struct termios my_serial;

  t_device_value = gtk_entry_get_text(GTK_ENTRY(gui_app->entry_sd));
  //open serial port with read and write, no controling terminal (we don't
  //want to get killed if serial sends CTRL-C), non-blocking 
  ser_dev = open(t_device_value, O_RDWR | O_NOCTTY );
  
  bzero(&my_serial, sizeof(my_serial)); // clear struct for new port settings 
        
  //B9600: set baud rate to 9600
  //   CS8     : 8n1 (8bit,no parity,1 stopbit)
  //   CLOCAL  : local connection, no modem contol
  //   CREAD   : enable receiving characters  */
  my_serial.c_cflag = B9600 | CS8 | CLOCAL | CREAD;
         
  tcflush(ser_dev, TCIFLUSH);
  tcsetattr(ser_dev,TCSANOW,&my_serial);

  //You can add code beyond this line but do not change anything above this line
  
}

/*!
 * \brief Checks if the "Close Device" button was clicked.
 * \param p_wdgt pointer to the widget structure
 * \param p_data gpointer to tell whether the button was clicked or not
 * \details Closes off the device from the program, making no longer in use until open again.
 */
extern "C" void button_closedevice_clicked(GtkWidget *p_wdgt, gpointer p_data ) 
{
  //this is how you disable a button:
  //gtk_widget_set_sensitive (gui_app->button_closedevice,FALSE);
  //this is how you enable a button:
  //gtk_widget_set_sensitive (gui_app->button_opendevice,TRUE);

  //do not change the next two lines; they close the serial port
  close(ser_dev);
  ser_dev=-1;

}

/*!
 * \brief Checks if the "Send" button was clicked.
 * \param p_wdgt pointer to the widget structure
 * \param p_data gpointer to tell whether the button was clicked or not
 * \details Sends the packets and data to the device.
 */
extern "C" void button_send_clicked(GtkWidget *p_wdgt, gpointer p_data ) 
{
  const char *t_red_value;
  unsigned char uc_red_value;
  const char *t_green_value;
  unsigned char uc_green_value;
  const char *t_blue_value;
  unsigned char uc_blue_value;
  char c_cc_value[40];
  char send_buff[7];
  int length_send_buff = 7;


  //getting text from widget:
  t_red_value = gtk_entry_get_text(GTK_ENTRY(gui_app->entry_red));
  int red = atoi(t_red_value);
  t_green_value = gtk_entry_get_text(GTK_ENTRY(gui_app->entry_green));
  int green = atoi(t_green_value);
  t_blue_value = gtk_entry_get_text(GTK_ENTRY(gui_app->entry_blue));
  int blue = atoi(t_blue_value);

  //setting range on scale slider to uc_red_value 
  gtk_range_set_value(GTK_RANGE(gui_app->scale_red),uc_red_value);
  gtk_range_set_value(GTK_RANGE(gui_app->scale_green),uc_green_value);
  gtk_range_set_value(GTK_RANGE(gui_app->scale_blue),uc_blue_value);
/*
int red = (int)t_red_value;
int green = (int)t_green_value;
int blue = (int)t_red_value;
*/

int checksum = ((((0xAA ^ 0x07)^ 'L')^ red)^green)^blue;

send_buff[0] = 0xAA;
send_buff[1] = 0x07;
send_buff[2] = 'L';
send_buff[3] = red;
send_buff[4] = green;
send_buff[5] = blue;
send_buff[6] = checksum;


		      
  //setting text on label
  //gtk_label_set_text(GTK_LABEL(gui_app->label_tx),c_cc_value);

  //this is how you send an array out on the serial port:
  write(ser_dev,send_buff,length_send_buff);
}

/*!
 * \brief Takes in the values for the color via slider and text entries.
 * \param p_wdgt pointer to the widget structure
 * \param p_data gpointer to tell whether the color values changed
 * \details Changes the value that leads to the change in color displayed from the LED.
 */
extern "C" void scale_rgb_value_changed(GtkWidget *p_wdgt, gpointer p_data ) 
{
  const char *t_red_value;
  unsigned char uc_red_value;
  const char *t_green_value;
  unsigned char uc_green_value;
  const char *t_blue_value;
  unsigned char uc_blue_value;
  char c_cc_value[40];
  char send_buff[7];
  int length_send_buff = 7;

  //getting the value of the scale slider 
  double g_red_value = gtk_range_get_value(GTK_RANGE(gui_app->scale_red));
  double g_green_value = gtk_range_get_value(GTK_RANGE(gui_app->scale_green));
  double g_blue_value = gtk_range_get_value(GTK_RANGE(gui_app->scale_blue));

  //setting text on entry
  sprintf(c_cc_value,"%d",uc_red_value);
  sprintf(c_cc_value,"%d",uc_green_value);
  sprintf(c_cc_value,"%d",uc_blue_value);
  gtk_entry_set_text(GTK_ENTRY(gui_app->entry_red),c_cc_value);
  gtk_entry_set_text(GTK_ENTRY(gui_app->entry_green),c_cc_value);
  gtk_entry_set_text(GTK_ENTRY(gui_app->entry_blue),c_cc_value);
  
}

/*!
 * \brief Checks if the "Exit" button was clicked.
 * \param p_wdgt pointer to the widget structure
 * \param p_data gpointer to tell whether the button was clicked or not
 * \details Once clicked the program will close.
 */
extern "C" void button_exit_clicked(GtkWidget *p_wdgt, gpointer p_data ) 
{
  gtk_main_quit();

}



//********************************************************************
//********************************************************************
// 
//   Main loop
//
//********************************************************************
//********************************************************************

/*!
 * \brief The main loop.
 * \details 
 */
int main(int argc, char **argv)
{

  GtkBuilder *builder;
  GError *err = NULL;

  GThread *read_thread;

  //this is how you allocate a Glib mutex
  g_assert(mutex_to_protect_voltage_display == NULL);
  mutex_to_protect_voltage_display = new GMutex;
  g_mutex_init(mutex_to_protect_voltage_display);

  // this is used to signal all threads to exit
  kill_all_threads=false;
  
  //spawn the serial read thread
  read_thread = g_thread_new(NULL,(GThreadFunc)Serial_Read_Thread,NULL);
  
  // Now we initialize GTK+ 
  gtk_init(&argc, &argv);
  
  //create gtk_instance for visualization
  gui_app = g_slice_new(Gui_Window_AppWidgets);

  //builder
  builder = gtk_builder_new();
  gtk_builder_add_from_file(builder, "teensy_control.glade", &err);

  
  //error handling
  if(err)
    {
      g_error(err->message);
      g_error_free(err);
      g_slice_free(Gui_Window_AppWidgets, gui_app);
      exit(-1);
    }

  // Obtain widgets that we need
  ObtainGuiWidgets(builder);

  // Connect signals
  gtk_builder_connect_signals(builder, gui_app);

  // Destroy builder now that we created the infrastructure
  g_object_unref(G_OBJECT(builder));

  //display the gui
  gtk_widget_show(GTK_WIDGET(gui_app->window1));

  //this is going to call the Voltage_Display_Displayer function periodically
  gdk_threads_add_timeout(VOLTAGE_DISPLAY_UPDATE_MS,Voltage_Display_Displayer,NULL);

  //the main loop
  gtk_main();

  //signal all threads to die and wait for them (only one child thread)
  kill_all_threads=true;
  g_thread_join(read_thread);
  
  //destroy gui if it still exists
  if(gui_app)
    g_slice_free(Gui_Window_AppWidgets, gui_app);

  return 0;
}
