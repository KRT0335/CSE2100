var searchData=
[
  ['obtainguiwidgets',['ObtainGuiWidgets',['../main_8cpp.html#a42831ac9db9027fad5a908cf6945ba5d',1,'main.cpp']]]
];
