var searchData=
[
  ['mutex_5fto_5fprotect_5fvoltage_5fdisplay',['mutex_to_protect_voltage_display',['../global_8cpp.html#ad451eecb5f887a85bdad2643e858e301',1,'mutex_to_protect_voltage_display():&#160;global.cpp'],['../global_8h.html#ad451eecb5f887a85bdad2643e858e301',1,'mutex_to_protect_voltage_display():&#160;global.cpp']]]
];
