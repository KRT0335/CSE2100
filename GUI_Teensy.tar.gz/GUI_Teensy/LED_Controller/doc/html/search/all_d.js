var searchData=
[
  ['voltage_5fdisplay_5fdisplayer',['Voltage_Display_Displayer',['../main_8cpp.html#aa6b3686a173a9e36b19c9e581c3126c9',1,'main.cpp']]],
  ['voltage_5fdisplay_5fupdate_5fms',['VOLTAGE_DISPLAY_UPDATE_MS',['../main_8cpp.html#a736aeda0653ee56f9d9a4fd12b45166e',1,'main.cpp']]]
];
