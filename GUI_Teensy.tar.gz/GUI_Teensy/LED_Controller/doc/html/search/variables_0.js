var searchData=
[
  ['button_5fclosedevice',['button_closedevice',['../structGui__Window__AppWidgets.html#a698b2ee1bcde9bf0a71d3ba204f24b51',1,'Gui_Window_AppWidgets']]],
  ['button_5fopendevice',['button_opendevice',['../structGui__Window__AppWidgets.html#add92bcaf28e61e6c2745c1dc9bd12452',1,'Gui_Window_AppWidgets']]]
];
