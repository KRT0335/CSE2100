var searchData=
[
  ['entry_5fblue',['entry_blue',['../structGui__Window__AppWidgets.html#ae8c4157ce01f19bb2e4cfca2bde2bfb3',1,'Gui_Window_AppWidgets']]],
  ['entry_5fgreen',['entry_green',['../structGui__Window__AppWidgets.html#a456eb5c588873181029475fc68c101fa',1,'Gui_Window_AppWidgets']]],
  ['entry_5fred',['entry_red',['../structGui__Window__AppWidgets.html#a96187a7f98a71a1e357f5b35b90e233e',1,'Gui_Window_AppWidgets']]],
  ['entry_5fsd',['entry_sd',['../structGui__Window__AppWidgets.html#a996d081f89c3558e5469ec5ea241354c',1,'Gui_Window_AppWidgets']]]
];
